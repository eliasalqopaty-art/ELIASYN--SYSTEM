import { createClient } from '@blinkdotnew/sdk'

export const blink = createClient({
  projectId: import.meta.env.VITE_BLINK_PROJECT_ID || 'file-diagnosis-site-crot82mn',
  publishableKey: import.meta.env.VITE_BLINK_PUBLISHABLE_KEY || 'blnk_pk_yYu60aKkz4u8V7yBbdwT3lna_V2qk6Od',
  authRequired: false,
  auth: { mode: 'managed' },
})
