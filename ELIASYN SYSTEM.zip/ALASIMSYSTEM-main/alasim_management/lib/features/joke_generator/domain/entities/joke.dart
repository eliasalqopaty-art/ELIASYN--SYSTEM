class Joke {
  final String id;
  final String type;
  final String setup;
  final String punchline;
  final String? delivery;

  Joke({
    required this.id,
    required this.type,
    required this.setup,
    required this.punchline,
    this.delivery,
  });

  factory Joke.fromJson(Map<String, dynamic> json) {
    return Joke(
      id: json['id'].toString(),
      type: json['type'] ?? 'single',
      setup: json['setup'] ?? json['joke'] ?? '',
      punchline: json['punchline'] ?? '',
      delivery: json['delivery'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'type': type,
      'setup': setup,
      'punchline': punchline,
      'delivery': delivery,
    };
  }

  String get fullJoke {
    if (type == 'single') {
      return setup;
    }
    return '$setup\n$punchline';
  }
}
