import 'package:dio/dio.dart';
import '../entities/joke.dart';

abstract class JokeRepository {
  Future<Joke> getRandomJoke();
  Future<Joke> getJokeByType(String type);
  Future<List<String>> getAvailableTypes();
}

class JokeRepositoryImpl implements JokeRepository {
  final Dio dio;
  static const String baseUrl = 'https://official-joke-api.appspot.com';

  JokeRepositoryImpl({required this.dio});

  @override
  Future<Joke> getRandomJoke() async {
    try {
      final response = await dio.get('$baseUrl/random_joke');
      return Joke.fromJson(response.data);
    } on DioException catch (e) {
      throw Exception('Failed to fetch joke: ${e.message}');
    }
  }

  @override
  Future<Joke> getJokeByType(String type) async {
    try {
      final response = await dio.get('$baseUrl/jokes/$type/random');
      if (response.data is List) {
        return Joke.fromJson(response.data[0]);
      }
      return Joke.fromJson(response.data);
    } on DioException catch (e) {
      throw Exception('Failed to fetch joke by type: ${e.message}');
    }
  }

  @override
  Future<List<String>> getAvailableTypes() async {
    try {
      final response = await dio.get('$baseUrl/types');
      final types = List<String>.from(response.data ?? []);
      return types;
    } on DioException catch (e) {
      throw Exception('Failed to fetch joke types: ${e.message}');
    }
  }
}
