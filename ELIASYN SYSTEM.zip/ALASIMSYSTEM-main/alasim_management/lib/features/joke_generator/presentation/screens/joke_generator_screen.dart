import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/joke_providers.dart';

class JokeGeneratorScreen extends ConsumerStatefulWidget {
  const JokeGeneratorScreen({Key? key}) : super(key: key);

  @override
  ConsumerState<JokeGeneratorScreen> createState() => _JokeGeneratorScreenState();
}

class _JokeGeneratorScreenState extends ConsumerState<JokeGeneratorScreen> {
  @override
  void initState() {
    super.initState();
    // Load initial joke
    Future.microtask(
      () => ref.read(refreshableJokeProvider.notifier).getRandomJoke(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final jokeAsyncValue = ref.watch(refreshableJokeProvider);
    final typesAsyncValue = ref.watch(jokeTypesProvider);
    final selectedType = ref.watch(selectedJokeTypeProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('😂 Joke Generator'),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              // Joke Display Card
              jokeAsyncValue.when(
                loading: () => _buildLoadingCard(),
                error: (error, stackTrace) => _buildErrorCard(error.toString()),
                data: (joke) => _buildJokeCard(joke),
              ),
              const SizedBox(height: 24),

              // Type Selector
              _buildTypeSelector(typesAsyncValue, selectedType),
              const SizedBox(height: 24),

              // Action Buttons
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () {
                        ref
                            .read(refreshableJokeProvider.notifier)
                            .getRandomJoke();
                      },
                      icon: const Icon(Icons.refresh),
                      label: const Text('New Joke'),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: jokeAsyncValue.whenData((joke) {
                        _shareJoke(joke.fullJoke);
                      }).asData != null
                          ? () {
                              jokeAsyncValue.whenData((joke) {
                                _shareJoke(joke.fullJoke);
                              });
                            }
                          : null,
                      icon: const Icon(Icons.share),
                      label: const Text('Share'),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildJokeCard(joke) {
    return Card(
      elevation: 4,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Colors.blue.shade50,
              Colors.purple.shade50,
            ],
          ),
        ),
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'ID: ${joke.id}',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Colors.grey,
                      ),
                ),
                Chip(
                  label: Text(joke.type.toUpperCase()),
                  backgroundColor: Colors.blue.shade200,
                )
              ],
            ),
            const SizedBox(height: 16),
            if (joke.setup.isNotEmpty)
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Setup:',
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    joke.setup,
                    style: Theme.of(context).textTheme.bodyLarge,
                  ),
                ],
              ),
            if (joke.punchline.isNotEmpty) const SizedBox(height: 16),
            if (joke.punchline.isNotEmpty)
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Punchline:',
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: Colors.green.shade700,
                        ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    joke.punchline,
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                          color: Colors.green.shade700,
                          fontWeight: FontWeight.w500,
                        ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingCard() {
    return Card(
      elevation: 4,
      child: Container(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const CircularProgressIndicator(),
            const SizedBox(height: 16),
            Text(
              'Loading a hilarious joke...',
              style: Theme.of(context).textTheme.bodyLarge,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildErrorCard(String error) {
    return Card(
      elevation: 4,
      color: Colors.red.shade50,
      child: Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.error, color: Colors.red.shade700),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Oops! Something went wrong',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          color: Colors.red.shade700,
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              error,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTypeSelector(AsyncValue<List<String>> typesAsyncValue, selectedType) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Select Joke Type:',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
        const SizedBox(height: 12),
        typesAsyncValue.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (error, _) => Text(
            'Failed to load types: $error',
            style: const TextStyle(color: Colors.red),
          ),
          data: (types) => Wrap(
            spacing: 8,
            runSpacing: 8,
            children: types
                .map(
                  (type) => FilterChip(
                    label: Text(type.toUpperCase()),
                    selected: selectedType == type,
                    onSelected: (selected) {
                      ref.read(selectedJokeTypeProvider.notifier).state = type;
                      ref
                          .read(refreshableJokeProvider.notifier)
                          .getJokeByType(type);
                    },
                  ),
                )
                .toList(),
          ),
        ),
      ],
    );
  }

  void _shareJoke(String joke) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Joke copied to clipboard!'),
        duration: const Duration(seconds: 2),
      ),
    );
    // In production, use the share plugin or copy to clipboard
  }
}
