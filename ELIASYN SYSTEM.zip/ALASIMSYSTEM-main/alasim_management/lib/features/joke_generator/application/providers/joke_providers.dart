import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dio/dio.dart';
import '../repositories/joke_repository.dart';
import '../entities/joke.dart';

// Provider for Dio instance
final dioProvider = Provider<Dio>((ref) {
  return Dio(BaseOptions(
    connectTimeout: const Duration(seconds: 10),
    receiveTimeout: const Duration(seconds: 10),
  ));
});

// Provider for Joke Repository
final jokeRepositoryProvider = Provider<JokeRepository>((ref) {
  final dio = ref.watch(dioProvider);
  return JokeRepositoryImpl(dio: dio);
});

// Provider for random joke
final randomJokeProvider = FutureProvider<Joke>((ref) async {
  final repository = ref.watch(jokeRepositoryProvider);
  return repository.getRandomJoke();
});

// Provider for jokes by type
final jokeByTypeProvider = FutureProvider.family<Joke, String>((ref, type) async {
  final repository = ref.watch(jokeRepositoryProvider);
  return repository.getJokeByType(type);
});

// Provider for available joke types
final jokeTypesProvider = FutureProvider<List<String>>((ref) async {
  final repository = ref.watch(jokeRepositoryProvider);
  return repository.getAvailableTypes();
});

// State for selected joke type
final selectedJokeTypeProvider = StateProvider<String?>((ref) => null);

// Refreshable provider to get new joke
final refreshableJokeProvider = StateNotifierProvider<JokeNotifier, AsyncValue<Joke>>((ref) {
  final repository = ref.watch(jokeRepositoryProvider);
  return JokeNotifier(repository);
});

class JokeNotifier extends StateNotifier<AsyncValue<Joke>> {
  final JokeRepository repository;

  JokeNotifier(this.repository) : super(const AsyncValue.loading());

  Future<void> getRandomJoke() async {
    state = const AsyncValue.loading();
    try {
      final joke = await repository.getRandomJoke();
      state = AsyncValue.data(joke);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }

  Future<void> getJokeByType(String type) async {
    state = const AsyncValue.loading();
    try {
      final joke = await repository.getJokeByType(type);
      state = AsyncValue.data(joke);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }
}
